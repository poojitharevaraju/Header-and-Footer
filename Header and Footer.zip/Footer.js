import React, { Component } from 'react'


export default class Footer extends Component{
    render(){
        return(
            <footer>
                <section>
                 <img src="https://www.achieversit.com/assets/images/logo-white.png" alt="logo"/>
                </section>
                <div>
                 <h2>COMPANY</h2>
                 <p>Home</p>
                 <p>placements</p>
                 <p>Corporate Training</p>
                <p>Contact Us</p>
                </div>

                <div>
                <h2>TRENDING COURSES</h2>
            <p>UIdevelopment Course</p>
            <p>Angular js Course</p>
            <p>React js Course</p>
            <p>Digital Marketing Course</p>
            <p>Python Course</p>
            </div>

            <div>
           <h2> CONTACT INFO</h2>
           <p></p>
           <p>#63, 1st Floor, 16th Main, 8th Cross,BTM 1st Stage, Bangalore, India - 560029</p>
           <p>India : +91 8431-040-457</p>
           <p>info@achieversit.com</p>
           </div>

            </footer>
        )
    }
}
