import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';

 class Header extends Component {
  render() {
    return (
        <>
        <header className='d-flex justify-content-between align-items-center p-3  bg-dark text-white'>
              <div>
              <img src="https://www.achieversit.com/assets/images/logo-white.png" alt="achieversit" />
         </div>
           <div>
           <nav>
            
              <ul className='d-flex list-unstyled m-0'>
                <li className='mx-3'>All Courses</li>
                <li className='mx-3'>Corporate Traning</li>
                <li className='mx-3'>Placements</li>
                <li className='mx-3'>Internship</li>
                <li className='mx-3'>Reviews</li>
                <li className='mx-3'>Blogs</li>
              </ul>
           </nav>

           </div>

        </header>
  
</>
        
        
     
    )
  }
}
export default Header